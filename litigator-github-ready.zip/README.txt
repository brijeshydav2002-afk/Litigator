
1. Upload all files to GitHub
2. Import repository into Vercel
3. Add environment variables:
   EMAIL_USER
   EMAIL_PASS
4. Deploy

Your OTP login will work automatically.
