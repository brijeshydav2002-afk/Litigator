
const nodemailer = require("nodemailer");

global.otpStore = global.otpStore || {};

module.exports = async (req, res) => {
  try {

    const { email } = req.body;

    if (!email) {
      return res.status(400).json({
        success: false,
        message: "Email required"
      });
    }

    const otp = Math.floor(
      100000 + Math.random() * 900000
    );

    global.otpStore[email] = otp;

    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
      }
    });

    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: email,
      subject: "Litigator OTP",
      text: `Your OTP is ${otp}`
    });

    res.status(200).json({
      success: true
    });

  } catch (e) {

    res.status(500).json({
      success: false,
      error: e.message
    });

  }
};
