
module.exports = async (req, res) => {

  const { email, otp } = req.body;

  if (global.otpStore[email] == otp) {

    return res.status(200).json({
      success: true
    });

  }

  res.status(400).json({
    success: false
  });

};
